# Task 7 — String Processing for Data Cleaning

def clean_text_records(records):
    cleaned = []
    for row in records:
        cleaned.append({
            "name": row["name"].strip().title(),
            "email": row["email"].strip().lower(),
            "category": row["category"].strip().lower().replace(" ", "_")
        })
    return cleaned

# Common string operations
text = "  Abhishek Kumar  "
print("strip:", text.strip())
print("lower:", text.lower())
print("upper:", text.upper())
print("replace:", text.replace("Abhishek", "A."))
print("split:", text.strip().split())

# Customer example
customers = [
    {"name":"  Rahul Sharma ", "email":" RAHUL@EXAMPLE.COM ", "category":" electronics "},
    {"name":"Priya Singh", "email":" priya@example.com", "category":"ELECTRONICS"}
]
print(clean_text_records(customers))

# Remove unwanted spaces
raw = "  Data   Science  "
print("normalized:", " ".join(raw.strip().split()))

# Extract information
email = "abhishek@example.com"
username, domain = email.split("@")
print("username:", username, "domain:", domain)

# Employee example
employees = [
    {"name":" mohan kumar ", "department":" IT "},
    {"name":"SNEHA GUPTA", "department":" human resources "}
]
clean_employees = [
    {"name":e["name"].strip().title(),
     "department":e["department"].strip().title()}
    for e in employees
]
print(clean_employees)
