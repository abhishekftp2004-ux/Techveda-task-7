# Task 7 — String Processing for Data Cleaning

## Description
Practice trimming spaces, changing case, replacing characters, splitting text, and extracting information.

## Objective
Build basic text-cleaning skills needed for real-world datasets.

## Deliverables
- Jupyter Notebook demonstrating common string methods
- Small text-cleaning function
- Examples for names, emails, and categories

## Topics
`strip()`, `lower()`, `upper()`, `replace()`, `split()`, whitespace normalization, email extraction, and category standardization.

## Interview Questions
1. Why is string cleaning important in data science?
2. What does `strip()` do?
3. How can you convert a string to lowercase?

## Top 5 Skills
1. Python Programming
2. String Manipulation
3. Data Cleaning
4. Data Standardization
5. Problem Solving & Data Preparation

## Status
Completed and submission-ready.
